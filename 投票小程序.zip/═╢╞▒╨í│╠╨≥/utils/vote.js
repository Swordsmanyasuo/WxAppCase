let voteList = [
  {
    title:'最佳篮球运动员',
    subtitle:'投票选取2021年最佳篮球运动员',
    name:"fcl",
    option:['牢大','勒布朗·詹姆斯','沙奎尔·奥尼尔','蒂姆·邓肯'],
    info:[
      {
        name:'付陈亮',
        value:'牢大'
      },
      {
        name:'纪霖琨',
        value:'牢大'
      },
      {
        name:'陈晨',
        value:'牢大'
      },
      {
        name:'吴洲全',
        value:'牢大'
      }
    ]
    
  }
]


export default voteList
